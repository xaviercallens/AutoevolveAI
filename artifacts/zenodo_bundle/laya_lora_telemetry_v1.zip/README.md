# Laya-LoRA Coding Companion — Zenodo Telemetry Archive

## Version: v1.0
## Date: 2026-09-30

This archive contains machine-derived telemetry receipts and Lean 4 formal proof
files for the Laya-LoRA Coding Companion paper.

## Contents

| File | Description |
|---|---|
| download_receipt.json | Dataset provenance: 10 datasets, 78,503 records, SHA-256 hashes |
| training_summary.json | 3-stage curriculum training results (loss, accuracy, duration) |
| coding_benchmark_and_comparison.json | 12-case benchmark results + model comparison |
| LayaDecision.lean | Lean 4 deployment invariants (I1: FLOP, I2: Budget, I3: Energy) |
| lakefile.lean | Lean 4 project build specification |

## SHA-256 Verification

All files are listed with their SHA-256 checksums in METADATA.json.
The telemetry JSON values are the ground-truth source for all numeric
claims in the paper (zero LLM hallucination — all values machine-derived).

## Lean 4 Sorry Obligation

LayaDecision.lean contains an unresolved `sorry` on Invariant I3
(`cpu_energy_bounded`). The file compiles with `lake build` but emits a warning.
This is the exact proof state used in the paper. Researchers wishing to
discharge the proof should implement the Lean 4 telemetry macro described
in Section 7.4 of the paper.

## Citation

If you use these artifacts, please cite:
  Callens, X. (2026). Laya-LoRA Coding Companion: Curriculum Training on 10
  Structured Coding Datasets. AutoevolveAI Open-Source Research.
  Zenodo DOI: 10.5281/zenodo.XXXXXXX
